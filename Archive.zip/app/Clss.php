<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clss extends Model
{
    public function campus(){
        return $this->belongsTo('App\Campus', 'class_campus_id' , 'id');
    }

    public function students(){
        return $this->belongsToMany('App\User', 'class_users', 'class_id', 'user_id');
    }

}
