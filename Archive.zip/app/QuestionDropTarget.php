<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuestionDropTarget extends Model
{
    //
}
