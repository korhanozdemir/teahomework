<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email','api_token'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token','api_token'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function hasRole($role){
        $hasRole = Roles::Select("users.id")
            ->leftJoin("users", "users.role", "=", "roles.id")
            ->where("roles.name", $role)
            ->where ("users.id", Auth::user()->id)
            ->count();
        if($hasRole>0){
            return true;
        }else {
            return false;
        }
    }

    public function getRole(){
        $role = Roles::select("name")
        ->find($this->role);

        if(isset($role['name'])){
            return $role['name'];
        }else {
            return false;
        }
    }

    public function getStudentUserDetails(){
        $authuser = Auth::user();
        if( !isset($authuser->role) || $authuser->role !== 3){
            return 0;
        }

        $student = $authuser->getStudentClass();
        $student = $student ? $student->toArray() : [];


        return (array_merge($authuser->toArray(), $student));


    }

    public function getStudentClass(){
        $userid = Auth::user()->id;
        $classId = ClassUser::select("class_users.class_id","clsses.class_name","clsses.class_level")
            ->where("user_id",$userid)
            ->leftJoin("clsses", "clsses.id", "=", "class_users.class_id")
            ->where("clsses.is_class_mixed", 0)
            ->first();
        return $classId;
    }

    public function getActiveHomework(){

        $user_id = Auth::user()->id;
        $homeworks = HomeworkUser::where("user_id", $user_id)
            ->where("start_date","<",date('Y-m-d H:i:s'))
            ->get();
        return $homeworks;
    }

    public function clsses(){
        return $this->belongsToMany('App\Clss', 'class_users', 'user_id', 'class_id');
    }

    public function homeworks(){
        return $this->belongsToMany('App\Homework', 'homework_users', 'user_id', 'homework_id');
    }

    public function roleName(){
        return $this->belongsTo('App\Roles','id');
    }


}
