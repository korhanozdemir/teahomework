<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Student Page</div>

                    <div class="card-body">
                        Content
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import StudentService from '../../services/student.service';

    export default {
        mounted() {
            console.log('Component mounted.');
        },
        created() {
            StudentService.getStudentDetails()
            .then((res)=>{
                toastr.success(res.data.name, 'Hoşgeldin!');
            });

            var questionResult = [
                {
                    question_index: 1,
                    matching: "1",
                    time : 2
                },
                {
                    question_index: 1,
                    matching: "1",
                    time : 2
                },
            ];

            StudentService.UpdateAllQuestionResult(1,1, questionResult)
            .then((res)=>{
                console.log(res);
            });


            StudentService.GetAllQuestionResult(1,1)
                .then((res)=>{
                    console.log(res);
                });
        }
    }
</script>

<style>

</style>
