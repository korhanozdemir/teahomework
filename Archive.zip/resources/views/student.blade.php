@extends('layouts.app')
@section('content')
    <student-page></student-page>
@endsection
