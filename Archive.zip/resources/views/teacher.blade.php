@extends('layouts.app')
@section('content')
    <teacher-page></teacher-page>
@endsection
